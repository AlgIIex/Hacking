clear
bi='\033[34;1m' #biru
i='\033[32;1m' #ijo
pur='\033[35;1m' #purple
cy='\033[36;1m' #cyan
me='\033[31;1m' #merah
pu='\033[37;1m' #purple
ku='\033[33;1m' #kuning

echo
figlet "P I L I H A N" | lolcat
echo $ku
figlet -f future "[1]" "Spam chat"
figlet -f future "[2]" "Spam call"
figlet -f future "[3]" "back"

echo
echo $i "╭─"$ku"AlgIIex"$i" <--> "$me"Thre3l"$i
read -p " ╰─> "  pil

if [ $pil = 1 ]
then
clear
echo $i
toilet -f standard "W A I T" -F gay
sleep 1
clear
cd /sdcard/hacking/script
php wa.php
cd /sdcard/hacking/script
sh spam.sh
fi

if [ $pil = 2 ]
then
clear
echo $ku
toilet -f standard "W A I T" -F gay
sleep 1
clear
cd /sdcard/hacking/script
php call.php
cd /sdcard/hacking/script
sh spam.sh
fi

if [ $pil = 3 ]
then
clear
echo $ku
toilet -f standard "W A I T" -F gay
sleep 1
cd /sdcard/hacking
sh h.sh
fi
